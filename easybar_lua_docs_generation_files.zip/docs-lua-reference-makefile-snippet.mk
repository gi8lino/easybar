# Merge this into your Makefile.

DOCS_VENV := .venv-docs
DOCS_PYTHON := $(DOCS_VENV)/bin/python
DOCS_STAMP := $(DOCS_VENV)/.requirements-installed

.PHONY: generate-lua-docs serve-docs build-docs clean-docs

$(DOCS_PYTHON):
	@python3 -m venv $(DOCS_VENV)

$(DOCS_STAMP): requirements-docs.txt | $(DOCS_PYTHON)
	@$(DOCS_PYTHON) -m pip install --upgrade pip
	@$(DOCS_PYTHON) -m pip install -r requirements-docs.txt
	@touch $(DOCS_STAMP)

generate-lua-docs: ## Generate Lua reference docs from LuaLS stubs.
	@python3 tools/generate_lua_reference_docs.py

serve-docs: $(DOCS_STAMP) generate-lua-docs ## Serve the docs locally.
	@$(DOCS_PYTHON) -m mkdocs serve

build-docs: $(DOCS_STAMP) generate-lua-docs ## Build the docs locally.
	@$(DOCS_PYTHON) -m mkdocs build --strict

clean-docs: ## Remove generated docs output and docs virtualenv.
	@rm -rf site $(DOCS_VENV) docs/lua/reference
