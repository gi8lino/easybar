# EasyBar Lua Docs Generation Files

This zip contains the Lua reference documentation generator and the hand-written Lua guide pages.

## Files

```text
tools/generate_lua_reference_docs.py

docs/lua/overview.md
docs/lua/guides/editor-support.md
docs/lua/guides/grouping.md
docs/lua/guides/popups.md
docs/lua/guides/intervals.md
docs/lua/guides/commands.md
docs/lua/guides/logging.md
docs/lua/guides/examples.md
docs/lua/guides/style-guidelines.md

docs/lua/reference/.gitkeep

docs-lua-reference-mkdocs-nav-snippet.yml
docs-lua-reference-makefile-snippet.mk
docs-lua-reference-github-actions-snippet.yml
```

## Usage

Unzip this archive at the repository root.

Then make the generator executable:

```bash
chmod +x tools/generate_lua_reference_docs.py
```

Generate reference docs:

```bash
python3 tools/generate_lua_reference_docs.py
```

This writes generated Markdown into:

```text
docs/lua/reference/
```

The generated reference pages should not be edited by hand. Update the LuaLS stub and regenerate them.
